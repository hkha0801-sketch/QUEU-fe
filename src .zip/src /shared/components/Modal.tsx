import React from "react";
import { FaTimes } from "react-icons/fa";
import { useGlobalContext } from "../../core/AppProvider";

export interface IModal {}

const Modal: React.FC<IModal> = (): React.ReactElement => {
  const { closeModal, isModalOpen } = useGlobalContext();

  return (
    <>
      <div
        className={`${
          isModalOpen ? "modal-overlay show-modal" : "modal-overlay"
        }`}
      >
        <div className="modal-container">
          <h3>modal content </h3>
          <button
            type="button"
            className="close-modal-btn"
            onClick={closeModal}
          >
            <FaTimes />
          </button>
        </div>
      </div>
    </>
  );
};

export default Modal;
